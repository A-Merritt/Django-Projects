"""LOGIN_APP CONFIGURATION

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.urls import path
from . import views

urlpatterns = [
    path('', views.log_and_reg), # main page that shows the form
    path('register', views.register), # Path hooked up to register form
    path('login',views.login), # path hooked up to Login Form
    path('index', views.index), # Path that generates a home page after you logged in.
    path('logout', views.logout), # path hooked up to the logout button.
    path('wall', views.wall),
    path('post_message', views.post_message),
    path('messages/<int:message_id>/post_comment', views.post_comment),
    path('users/<int:user_id>', views.user),
    path('messages/<int:message_id>/like', views.like),
    path('messages/<int:message_id>/dislike', views.dislike),
    path('messages/<int:message_id>/edit', views.edit),
    path('messages/<int:message_id>/update', views.update),
    path('users/<int:user_id>/update', views.update_user)

]
