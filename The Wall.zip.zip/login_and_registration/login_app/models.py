from django.db import models
import re

# Create your models here.
class MessageManager(models.Manager):  #Since we create a model Message, we need a validator for this model so we can make sure we get valid input from the web user.
    def validator(self, postData):
        errors = {}
        if len(postData['content']) < 1:
            errors['content'] = "Message cannot be blank."
        return errors

class CommentManager(models.Manager):  #Since we create a model Message, we need a validator for this model so we can make sure we get valid input from the web user.
    def validator(self, postData):
        errors = {}
        if len(postData['content']) < 1:
            errors['content'] = "Comment cannot be blank."
        return errors

class UserManager(models.Manager):
    def register_validator(self, postData):
        errors = {}
        users = User.objects.filter(email_address=postData["email"])
        if users:
            errors['existing_user'] = "Account with email already exists"
        EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
        if not EMAIL_REGEX.match(postData['email']):               
            errors['email'] = ("Invalid email address!")
        if len(postData["first_name"]) < 2:
            errors["first_name"] = "First Name should be at least 2 Characters."
        if len(postData['last_name']) < 2:
            errors["last_name"] = "Last Name should be at least 2 Characters."
        if len(postData["password"]) < 8:
            errors["password"] = "Password should be at least 8 Characters."
        if postData["password"] != postData["confirm_password"]:
            errors["confirm_password"] = "Passwords must match"
        return errors

    def login_validator(self, postData):
        errors = {}
        users = User.objects.filter(email_address=postData["email"])
        if len(postData['email']) < 1:
            errors['email'] = "Email cannot be blank."
        if len(postData["password"]) < 8:
            errors["password"] = "Password should be at least 8 Characters."
        return errors
    
    def edit_validator(self, postData, user_id):
        errors = {}
        users = User.objects.filter(email=postData['email']) #3This line is taking email form the form and filtering it through all objects of the User model
        user_tied_to_email = users[0]
        if users:  #if it exists, then it is already ours or belongs to someone else
            my_user = User.objects.get(id=user_id)
            if my_user.email_address != user_tied_to_email.email_address:
                errors['email']= "Email is already in use."  #print off warning
            else:
                if len(postData["first_name"]) < 2:
                    errors["first_name"] = "First Name should be at least 2 Characters."
                if len(postData['last_name']) < 2:
                    errors["last_name"] = "Last Name should be at least 2 Characters."
                if len(postData["password"]) < 8:
                    errors["password"] = "Password should be at least 8 Characters."
                if postData["password"] != postData["confirm_password"]:
                    errors["confirm_password"] = "Passwords must match"
        else:
            if len(postData["first_name"]) < 2:
                    errors["first_name"] = "First Name should be at least 2 Characters."
            if len(postData['last_name']) < 2:
                errors["last_name"] = "Last Name should be at least 2 Characters."
            if len(postData["password"]) < 8:
                errors["password"] = "Password should be at least 8 Characters."
            if postData["password"] != postData["confirm_password"]:
                errors["confirm_password"] = "Passwords must match"
        return errors


class User(models.Model):
    first_name = models.CharField(max_length=45)
    last_name = models.CharField(max_length=45)
    email_address = models.CharField(max_length=255)
    password = models.CharField(max_length=255, null=True)
    created_at = models.DateTimeField(auto_now=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = UserManager()

class Message(models.Model):
    content = models.TextField()
    creator = models.ForeignKey(User, related_name="messages", on_delete=models.CASCADE)
    users_who_liked = models.ManyToManyField(User, related_name="messages_user_liked")
    created_at = models.DateTimeField(auto_now=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = MessageManager()

class Comment(models.Model):
    content = models.TextField()
    creator = models.ForeignKey(User, related_name="comments", on_delete=models.CASCADE)
    message = models.ForeignKey(Message, related_name="comments", on_delete=models.CASCADE, null=True)
    users_who_liked = models.ManyToManyField(User, related_name="comments_user_liked")
    created_at = models.DateTimeField(auto_now=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = CommentManager()